# Assignment for Forest Cover Type Prediction


## Task 1.
The project which you have built, you need to modify the architecture of the project by updating Data Ingestion Component.

1. Instead of fetching data from MongoDb extract data from local zip file which will get saved in your project directory.
2. Save Extracted data into ingested artifacts

## Task 2.

The project which you have built, you need to modify the architecture of the project by updating Data Validation Component.

1. Try to implement code to check outliers.
2. Learn to create schema file using python script


## Task 3.

Here we have deployed using AWS S3 and EC2 .

1. Try learning deployment on Azure and GCP.
2. Create a proper document with explanation.

